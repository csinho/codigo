import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabsets',
  templateUrl: './tabsets.component.html',
  styleUrls: ['./tabsets.component.scss']
})
export class TabsetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
