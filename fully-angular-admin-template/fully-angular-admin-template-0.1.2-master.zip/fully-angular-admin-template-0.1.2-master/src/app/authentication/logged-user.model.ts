export class LoggedUserModel {
  image: string;
  name: string;
  lastname: string;
  email: string;
}
