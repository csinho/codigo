import { Directive } from '@angular/core';

@Directive({
  selector: '[appShowHideInput]'
})
export class ShowHideInputDirective {

  constructor() {}

}
