Please check documentation to see how to customize the palettes.

Contrast web accessibility
- To calculate the color contrasts we use this tool https://contrast-finder.tanaguru.com/result.html. Make sure the contrast ratio is at least 3.0
