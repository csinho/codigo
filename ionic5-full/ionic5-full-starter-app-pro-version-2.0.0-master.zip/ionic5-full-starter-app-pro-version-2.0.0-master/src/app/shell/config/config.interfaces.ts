export interface IAppShellConfig {
  debug: boolean;
  networkDelay: number;
}
