import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-shell-page',
  templateUrl: './image-shell.page.html',
  styleUrls: ['./image-shell.page.scss'],
})
export class ImageShellPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
