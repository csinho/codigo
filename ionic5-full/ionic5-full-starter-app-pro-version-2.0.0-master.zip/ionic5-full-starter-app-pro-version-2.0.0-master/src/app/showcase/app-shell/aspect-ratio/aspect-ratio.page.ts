import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aspect-ratio-page',
  templateUrl: './aspect-ratio.page.html',
  styleUrls: ['./aspect-ratio.page.scss'],
})
export class AspectRatioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
