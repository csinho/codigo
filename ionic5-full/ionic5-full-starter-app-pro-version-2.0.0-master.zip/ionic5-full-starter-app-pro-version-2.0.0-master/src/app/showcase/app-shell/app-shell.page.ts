import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showcase-shell',
  templateUrl: './app-shell.page.html',
  styleUrls: ['./app-shell.page.scss']
})
export class AppShellPage implements OnInit {

  constructor() { }

  ngOnInit(): void {

  }
}
