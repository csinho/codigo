import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-shell-page',
  templateUrl: './text-shell.page.html',
  styleUrls: ['./text-shell.page.scss'],
})
export class TextShellPage implements OnInit {
  sampleTextShellData = '';

  constructor() { }

  ngOnInit() {
  }

}
