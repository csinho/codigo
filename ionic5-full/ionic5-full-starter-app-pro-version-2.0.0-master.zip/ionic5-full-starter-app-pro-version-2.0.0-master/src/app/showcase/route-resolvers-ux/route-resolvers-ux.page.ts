import { Component } from '@angular/core';

@Component({
  selector: 'app-showcase-route-resolvers-ux',
  templateUrl: './route-resolvers-ux.page.html',
  styleUrls: ['./route-resolvers-ux.page.scss']
})

export class RouteResovlersUXPage {

  constructor() { }

}
