import { ShellModel } from '../../../shell/data-store';

export class UserImageModel extends ShellModel {
  link: string;

  constructor() {
    super();
  }
}
