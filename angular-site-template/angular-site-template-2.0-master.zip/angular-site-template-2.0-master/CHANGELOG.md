# 20 Jan 2020 - v2.0.0
- Update project to Angular 8
- Remove APP_BASE_HREF and added Angular UniversalInterceptor (learn more in https://angular.io/guide/universal#using-absolute-urls-for-server-requests)
- Updated all libraries

# 17 December 2018 - v1.1.0
- Update to Angular 7
- Removed webpack process and replaced it with tsc
- Updated all libraries to its latest versions
