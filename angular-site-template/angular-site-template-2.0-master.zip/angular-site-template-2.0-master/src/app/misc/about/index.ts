export { AboutPageComponent } from './components/about-page/about-page.component';
export { AboutPageResolver } from './resolvers/about-page.resolver';

export { MiscAboutModule } from './misc-about.module';
