export { ProductPageComponent } from './components/product-page/product-page.component';
export { ProductPageResolver } from './resolvers/product-page.resolver';

export { StoreProductModule } from './store-product.module';
