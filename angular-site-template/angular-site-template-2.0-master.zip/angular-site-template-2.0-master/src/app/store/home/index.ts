export { HomeStorefrontPageComponent } from './components/storefront-page/storefront-page.component';
export { HomeStorefrontPageResolver } from './resolvers/storefront-page.resolver';

export { StoreHomeModule } from './store-home.module';
