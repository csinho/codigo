import { NgModule } from '@angular/core';

import { UserService } from './services/user.service';

@NgModule({
  declarations: [],
  imports: [],
  entryComponents: [],
  providers: [
    UserService
  ],
  exports: []
})
export class UserSharedModule { }
