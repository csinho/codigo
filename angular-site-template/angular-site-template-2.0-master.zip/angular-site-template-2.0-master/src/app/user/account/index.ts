export { UserAccountPageComponent } from './components/account-page/user-account-page.component';
export { UserAccountPageResolver } from './resolvers/user-account-page.resolver';

export { UserAccountModule } from './user-account.module';
