export { Error404PageComponent } from './404/error-404-page.component';
export { FooterComponent } from './footer/footer.component';
export { SEODirective } from './seo/seo.directive';
export { TopNavbarComponent } from './top-navbar/top-navbar.component';

export { CoreModule } from './core.module';
