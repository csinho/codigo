export { AuthRecoverPasswordPageComponent } from './components/recover-password-page/auth-recover-password-page.component';
export { AuthRecoverPasswordPageResolver } from './resolvers/auth-recover-password-page.resolver';

export { AuthRecoverPasswordModule } from './auth-recover-password.module';
