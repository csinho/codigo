export { AuthSignupPageComponent } from './components/signup-page/auth-signup-page.component';
export { AuthSignupPageResolver } from './resolvers/auth-signup-page.resolver';

export { AuthSignupModule } from './auth-signup.module';
